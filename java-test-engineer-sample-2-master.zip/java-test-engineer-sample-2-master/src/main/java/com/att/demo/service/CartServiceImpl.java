package com.att.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.att.demo.model.Cart;
import com.att.demo.model.Product;



@Service("cartService")
public class CartServiceImpl implements CartService{
	
private Map  defineCart() {

//move this functionality to Mockito
	HashMap<String, Cart> catMap = new HashMap<String, Cart>();
	Product p1=new Product("Rice", 2,2.0);
	Product p2=new Product("Table", 3,100.0);
		
	Cart c1= new Cart((long) 1,p1);
	Cart c2= new Cart((long) 2,p2);
	catMap.put("1", c1);
	catMap.put("2", c2);
	return catMap;
}

	@Override
	public Cart findCart(long id) {
		// TODO Auto-generated method stub
		
		return	(Cart) defineCart().get(id);
	
	}

	@Override
	public void saveCart(Cart cart) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCart(long id) {
		defineCart().remove(id);
		
	}

	@Override
	public void updateCart(Cart cart) {
		defineCart().put(cart.getCartId(), cart);
		
	}	
	
}
