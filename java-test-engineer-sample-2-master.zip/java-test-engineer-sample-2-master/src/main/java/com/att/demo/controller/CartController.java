package com.att.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.demo.model.Cart;
import com.att.demo.service.CartService;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @RequestMapping(method = RequestMethod.POST,  consumes = "application/json")
    public void addProductItem(@RequestBody Cart cart) {
        cartService.saveCart(cart);
    }


    @RequestMapping(method =RequestMethod.GET,value ="/{id}", produces = "application/json")
    @ResponseBody
    public  Cart findCart(@PathVariable("id") Long ids){
    	
        return cartService.findCart(ids);
    }

    @RequestMapping(method = RequestMethod.PUT, consumes = "application/json")
    public void updateProductItem(@RequestBody Cart cart) {
         cartService.updateCart(cart);
    }

    @RequestMapping(method = RequestMethod.DELETE, value ="/{id}")
    public void deleteCart(@PathVariable("id") Long ids) {
        cartService.deleteCart(ids);
    }

}