package com.att.demo.resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

/**
 * This is the Controller class for Account mService
 * 
 * 
 */
@Controller
public class CartResourceImpl implements CartResource {
	
	public static final Logger logger = LoggerFactory.getLogger(CartResourceImpl.class);

		

}