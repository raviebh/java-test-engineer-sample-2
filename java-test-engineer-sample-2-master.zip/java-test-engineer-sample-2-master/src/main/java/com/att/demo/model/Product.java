package com.att.demo.model;

import io.swagger.annotations.ApiModel;

@ApiModel(value = "Product",
description = "Product domain object")
public class Product {

	    private String description;
	

	    private Integer quantity;
	

	    public Product(String description, Integer quantity, Double unitPrice) {
			super();
			this.description = description;
			this.quantity = quantity;
			this.unitPrice = unitPrice;
		}


		public String getDescription() {
			return description;
		}


		public void setDescription(String description) {
			this.description = description;
		}


		public Integer getQuantity() {
			return quantity;
		}


		public void setQuantity(Integer quantity) {
			this.quantity = quantity;
		}


		public Double getUnitPrice() {
			return unitPrice;
		}


		public void setUnitPrice(Double unitPrice) {
			this.unitPrice = unitPrice;
		}


		private Double unitPrice;
}

