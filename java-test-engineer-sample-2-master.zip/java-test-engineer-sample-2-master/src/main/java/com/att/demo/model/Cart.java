package com.att.demo.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "Cart",
description = "Cart domain object")
public class Cart implements Serializable{
	
	Long CartId;
	
	Product product;

	public Cart(Long cartId, Product product) {
		super();
		CartId = cartId;
		this.product = product;
	}

	public Long getCartId() {
		return CartId;
	}

	public void setCartId(Long cartId) {
		CartId = cartId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	

}
